****COMPILAZIONE***

Compiling Folder structure
--/src
      /*.java
--/classes
      /*.class

***COMPILING***

----TO COMPILE Dijkstra DATA STRUCTURE IN PACKAGE dijkstra---
1) place terminal in .../src
2) javac -d ../classes dijkstra/DijkstraMinPath.java

---TO COMPILE DijkstraAppl IN PACKAGE dijkstra---
1) place terminal .../src
2) javac -d ../classes dijkstra/*.java 


***RUNNING***


---TO RUN dijkstra/DijkstraAppl
1) place terminal .../classes 
2) java dijkstra/dijkstraAppl


