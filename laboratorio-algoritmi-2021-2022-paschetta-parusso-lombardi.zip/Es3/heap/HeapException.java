package heap;

/**
 * Exception throwable by Heap class
 * @author paschetta 
 * @author parusso 
 * @author lombardi
*/

public class HeapException extends Exception {
    public HeapException(String message) {
        super(message);
    }
}
